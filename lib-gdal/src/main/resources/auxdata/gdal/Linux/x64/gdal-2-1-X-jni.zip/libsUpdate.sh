echo Updating JNI libraries RPATH...
patchelf --set-rpath '/usr/local/lib:/usr/lib' libgdalconstjni.so
readelf -d libgdalconstjni.so
patchelf --set-rpath '/usr/local/lib:/usr/lib' libgdaljni.so
readelf -d libgdaljni.so
patchelf --set-rpath '/usr/local/lib:/usr/lib' libogrjni.so
readelf -d libogrjni.so
patchelf --set-rpath '/usr/local/lib:/usr/lib' libosrjni.so
readelf -d libosrjni.so
echo Updating JNI libraries RPATH DONE
