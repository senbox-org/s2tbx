echo Libs Updater
target_lib_path=$1
if [ $target_lib_path == “” ]; then
	echo "Enter target library path: "
	read target_lib_path
fi
target_lib_name=$(basename $target_lib_path)
target_lib_dir=$(dirname $target_lib_path)
dependency_lib_path=$2
if [ $dependency_lib_path == “” ]; then
	echo "Enter dependency library path: "
	read dependency_lib_path
fi
dependency_lib_name=$(basename $dependency_lib_path)
new_dependency_lib_name=./$dependency_lib_name
new_dependency_lib_path=$target_lib_dir/$dependency_lib_name
echo “Updating dependency $dependency_lib_name with path: $dependency_lib_path for library $target_lib_name with path: $target_lib_path

status=0
cd $target_lib_dir
status=$((status+$?))
if [ ! -f “$new_dependency_lib_path” -a $status -eq 0 ]; then
	cp $dependency_lib_path $new_dependency_lib_path
	status=$((status+$?))
	if [ $status -eq 0 ]; then
		echo ***change id: $dependency_lib_path with: $new_dependency_lib_name for: $new_dependency_lib_path
		install_name_tool -id $new_dependency_lib_name $new_dependency_lib_path
		status=$((status+$?))
	fi
fi
if [ $status -eq 0 ]; then
	echo ***change dependency: $dependency_lib_path with: $new_dependency_lib_name in: $target_lib_path
	install_name_tool -change $dependency_lib_path $new_dependency_lib_name $target_lib_path
	status=$((status+$?))
fi

otool -L $target_lib_name
if [ $status -eq 0 -a $? -eq 0 ]; then
	echo DONE for $target_lib_name
else
	echo FAILED for $target_lib_name
fi

install_name_tool -change @loader_path/../liblzma.5.dylib @loader_path/liblzma.5.dylib libxml2.2.dylib